// Array
// ..const numeros = ['olá', 10, true, {}]..

//Escolher qual ds posições do array imprimir, começando do 0
// ..console.log(numeros[0])..

// Estou trazendo cadâ informação do meu array para uma variável
// ..const [saudacao,numero,booleano,aluno] = numeros..

//Spread e Rest, Spread cria um clone do array, Rest armazena todo o resto
// ..const [saudacao2,...resto] = numero..

// //Serve para mudar ou adicionar itens dentro de uma lista
// ..numeros[4] = 'Carol'..
// ..console.log(numeros)..

//Como saber o tamanho do meu array, ou seja saber ate onde temos que ir, quantidade.
// ..console.log(numeros.length)..
