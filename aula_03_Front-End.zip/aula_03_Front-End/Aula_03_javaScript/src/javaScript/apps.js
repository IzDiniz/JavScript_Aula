//Query selector pega o docuento do index
const listaFilmes = document.querySelector('#listaFilmes')
// const filmeInput = document.querySelector('#filmeInput').value
// const btn1 = document.querySelector('button')
// const filmes = ['Star wars', 'Need For Speed', 'Carros', 'As Branquelas', 'MIB']
// filmes.push('Senhor dos aneis')
// filmes.pop()
// window.onload = function carregarFilmes(){
// }
const filmes = [{
    nome: 'Harry Potter',
    lancamento: 2001,
    genero: 'Fantasia',
    atores: {
        ator1: 'Daniel RadCliff'
    }
}, {
    nome: 'vovozona',
    lancamento: 2000,
    genero: 'comédia'
}]

// btn1.addEventListener('click', () =>{
//     let filmesDigitado = filmeInput.value
//     filmes.push(filmesDigitado)
//     // return filmesDigitado
// })

//Isto é igual ao onload = function, so que function anonima


// window.onload = () => {
//     //O PRIMEIRO let i conta quantas vezs passa no loop //O SEGUNDO conta quantas vezes ele vai passar o loop, ou seja a condição 
//     //O TERCEIRO adiciona 1 na quantidades para chegar no seu limite de codições
//     for(let i=0; i < filmes.length; i++){
//         let itemLista = document.createElement('li'); //criando um elemanto, adiciona um elemento html
//         listaFilmes.append(itemLista)
//         itemLista.innerHTML = filmes[i].nome
//       >>>>>  // itemLista.innerHTML = filmes[i].nome
//       >>>>> // itemLista.classList.add(itemFavorito)

//         let anoLancamento = document.createElement('span') //Adicionando
//         itemLista.append(anoLancamento)
//         anoLancamento.innerHTML = filmes[i].lancamento
//     }
// }

filmes.forEach(function(meuElemento){
    console.log(meuElemento.nome + 'Vai santos')
})