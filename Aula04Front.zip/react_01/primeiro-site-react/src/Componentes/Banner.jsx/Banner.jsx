import './Banner.css'

function Banner (props){
    return (
        <header>
        <h1 className="titulo-banner">{props}</h1>
        <p>Paragrafo do meu Banner</p>
        </header>
    )
}

export default Banner