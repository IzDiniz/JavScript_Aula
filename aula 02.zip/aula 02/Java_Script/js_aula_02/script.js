//Trazendo o prompt -sync para nosso projeto -- npm i prompt -sync
const prompt = require('prompt-sync')()

function getUserInfo(){
    let altura = parseFloat(prompt("Digite sua altura: "))
    let peso = parseFloat(prompt("Digite sua altura: "))

    // Criar uma saída 
    // Objeto é criado dentro de 2 chavinhas
    return {
        pesoInformado: peso,
        alturaInformada: altura
    }
}
function calcImc(aluraDoUsuario = 0, pesoDoUsuario = 0){
    return pesoDoUsuario / aluraDoUsuario**2
}
function main(){
    let peso = getUserInfo().pesoInformado
    let altura = getUserInfo().alturaInformada
    let imc = calcImc(alura,peso)
    console.log(`Seu IMC é ${imc}`)
}

// Chamando a função para ser execultada
// getUserInfo()
